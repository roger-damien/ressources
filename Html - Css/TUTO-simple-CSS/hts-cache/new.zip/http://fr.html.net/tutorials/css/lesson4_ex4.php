<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<title>Exemple | Tutoriel CSS | HTML.net</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link rel="stylesheet" href="/tutorials/css/lesson4_ex4.css" type="text/css" media="all" />
</head>
<body>
	<p>&nbsp;</p>

	<table border="1" cellpadding="10">
	<tr>
	<td>Du texte en caractères gras dans les cellules</td>
	</tr>
	</table>

	<p>Du texte normal ici</p>
	
	</body>
</html>