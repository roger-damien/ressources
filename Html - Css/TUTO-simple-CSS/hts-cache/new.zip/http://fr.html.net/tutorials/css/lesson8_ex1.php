<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<title>Exemple | Tutoriel CSS | HTML.net</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link rel="stylesheet" href="/tutorials/css/lesson8_ex1.css" type="text/css" media="all" />
</head>
<body>
	<h1>Citation de Benjamin Franklin - les avantages mis en exergue</h1>

	<p>Tôt couché et tôt levé <span class="benefit">fortifie</span>, <span class="benefit">enrichit</span> et <span class="benefit">rend avisé</span>.</p>
	
	</body>
</html>