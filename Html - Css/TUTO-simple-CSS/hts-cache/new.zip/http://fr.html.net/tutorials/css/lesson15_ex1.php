<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<title>Exemple | Tutoriel CSS | HTML.net</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link rel="stylesheet" href="/tutorials/css/lesson15_ex1.css" type="text/css" media="all" />
</head>
<body>
	<h1>Suite royale</h1>

	<div id="ten_of_diamonds">
	<img src="diamonds_10.gif" alt="10 of diamonds">
	</div>

	<div id="jack_of_diamonds">
	<img src="diamonds_jack.gif" alt="Jack of diamonds">
	</div>

	<div id="queen_of_diamonds">
	<img src="diamonds_queen.gif" alt="Queen of diamonds">
	</div>

	<div id="king_of_diamonds">
	<img src="diamonds_king.gif" alt="King of diamonds">
	</div>

	<div id="ace_of_diamonds">
	<img src="diamonds_ace.gif" alt="Ace of diamonds">
	</div>	
	</body>
</html>