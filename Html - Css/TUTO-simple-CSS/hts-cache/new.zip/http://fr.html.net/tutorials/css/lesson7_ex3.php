<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<title>Exemple | Tutoriel CSS | HTML.net</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link rel="stylesheet" href="/tutorials/css/lesson7_ex3.css" type="text/css" media="all" />
</head>
<body>
	<h1 id="c1">Chapitre 1</h1>
	<p>...</p>
	<h2 id="c1-1">Chapitre 1.1</h2>
	<p>...</p>
	<h2 id="c1-2">Chapitre 1.2</h2>
	<p>...</p>
	<h1 id="c2"> Chapitre2</h1>
	<p>...</p>
	<h2 id="c2-1">Chapitre 2.1</h2>
	<p>...</p>
	<h3 id="c2-1-2">Chapitre 2.1.2</h3>
		
	</body>
</html>