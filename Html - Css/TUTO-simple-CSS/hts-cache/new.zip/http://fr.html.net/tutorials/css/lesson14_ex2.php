<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<title>Exemple | Tutoriel CSS | HTML.net</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link rel="stylesheet" href="/tutorials/css/lesson14_ex2.css" type="text/css" media="all" />
</head>
<body>
	<h1>The Tinder-Box</h1>

	<p><strong>By Hans Christian Andersen</strong></p>

	<p>A soldier came marching along the high road: &quot;Left, right -- left, right.&quot; He had his knapsack on his back, and a sword at his side; he had been to the wars, and was now returning home. </p>
	<p>As he walked on, he met a very frightful-looking old witch in the road. Her under-lip hung quite down on her breast, and she stopped and said, &quot;Good evening, soldier; you have a very fine sword, and a large knapsack, and you are a real soldier; so you shall have as much money as ever you like.&quot; </p>
	<p>&quot;Thank you, old witch,&quot; said the soldier. </p>
	<p>&quot;Do you see that large tree,&quot; said the witch, pointing to a tree which stood beside them. &quot;Well, it is quite hollow inside, and you must climb to the top, when you will see a hole, through which you can let yourself down into the tree to a great depth. I will tie a rope round your body, so that I can pull you up again when you call out to me.&quot; </p>
	<p>&quot;But what am I to do, down there in the tree?&quot; asked the soldier. </p>
	<div id="dog1"><img src="dog1.gif"></div>
	<p>&quot;Get money,&quot; she replied; &quot;for you must know that when you reach the ground under the tree, you will find yourself in a large hall, lighted up by three hundred lamps; you will then see three doors, which can be easily opened, for the keys are in all the locks. On entering the first of the chambers, to which these doors lead, you will see a large chest, standing in the middle of the floor, and upon it a dog seated, with a pair of eyes as large as teacups. But you need not be at all afraid of him; I will give you my blue checked apron, which you must spread upon the floor, and then boldly seize hold of the dog, and place him upon it. You can then open the chest, and take from it as many pence as you please, they are only copper pence; but if you would rather have silver money, you must go into the second chamber. Here you will find another dog, with eyes as big as mill-wheels; but do not let that trouble you. Place him upon my apron, and then take what money you please. If, however, you like gold best, enter the third chamber, where there is another chest full of it. The dog who sits on this chest is very dreadful; his eyes are as big as a tower, but do not mind him. If he also is placed upon my apron, he cannot hurt you, and you may take from the chest what gold you will.&quot; </p>
	<p>&quot;This is not a bad story,&quot; said the soldier; &quot;but what am I to give you, you old witch? for, of course, you do not mean to tell me all this for nothing.&quot; </p>
	<div id="dog2"><img src="dog2.gif"></div>
	<p>&quot;No,&quot; said the witch; &quot;but I do not ask for a single penny. Only promise to bring me an old tinder-box, which my grandmother left behind the last time she went down there.&quot; </p>
	<p>&quot;Very well; I promise. Now tie the rope round my body.&quot; </p>
	<p>&quot;Here it is,&quot; replied the witch; &quot;and here is my blue checked apron.&quot; </p>
	<p>As soon as the rope was tied, the soldier climbed up the tree, and let himself down through the hollow to the ground beneath; and here he found, as the witch had told him, a large hall, in which many hundred lamps were all burning. Then he opened the first door. &quot;Ah!&quot; there sat the dog, with the eyes as large as teacups, staring at him. </p>
	<p>&quot;You're a pretty fellow,&quot; said the soldier, seizing him, and placing him on the witch's apron, while he filled his pockets from the chest with as many pieces as they would hold. Then he closed the lid, seated the dog upon it again, and walked into another chamber, And, sure enough, there sat the dog with eyes as big as mill-wheels. </p>
	<p>&quot;You had better not look at me in that way,&quot; said the soldier; &quot;you will make your eyes water;&quot; and then he seated him also upon the apron, and opened the chest. But when he saw what a quantity of silver money it contained, he very quickly threw away all the coppers he had taken, and filled his pockets and his knapsack with nothing but silver. </p>
	<div id="dog3"><img src="dog3.gif"></div>
	<p>Then he went into the third room, and there the dog was really hideous; his eyes were, truly, as big as towers, and they turned round and round in his head like wheels...</p>	
	</body>
</html>