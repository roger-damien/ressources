
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>

	<title>Tutoriel CSS - Table des matières - HTML.net</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="title" content="Tutoriel CSS - Table des matières - HTML.net" />
	<meta name="description" content="Tutoriel CSS - Table des matières - Tutoriels sur HTML et CSS - Construisez votre propre site Web" />
	<meta name="keywords" content="HTML, CSS, XHTML, Tutoriel HTML, Tutoriel CSS, Forums, , " />
	<meta name="language" content="fr" />
	<meta name="robots" content="index, follow" />
	<meta http-equiv="PICS-Label" content='(PICS-1.1 "http://www.classify.org/safesurf/" l gen true for "http://html.net/" r (SS~~000 1))' />
	<meta http-equiv="PICS-Label" content='(PICS-1.1 "http://www.icra.org/ratingsv02.html" l gen true for "http://html.net" r (cz 1 lz 1 nz 1 oz 1 vz 1) "http://www.rsac.org/ratingsv01.html" l gen true for "http://html.net" r (n 0 s 0 v 0 l 0))' /> 
	<meta property="og:title" content="Tutoriel CSS - Table des matières - HTML.net" />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="http://fr.html.net/tutorials/css/index.php" />
	<meta property="og:image" content="http://html.net/avatar.png" />
	<meta property="og:site_name" content="HTML.net" />
	<meta property="fb:admins" content="610699221" />
	<link rel='stylesheet' href='http://html.net/site/style/default.screen.css' type='text/css' media='screen' /><link rel='stylesheet' href='http://html.net/site/style/default.print.css' type='text/css' media='print' />
	<script type="text/javascript">
			
		function toggleVisibility(objectID, imageID) {
		vis = document.getElementById(objectID).style;
		state = vis.display;
		if (state == 'none') {
			vis.display = 'block';	
			document.getElementById(imageID).value = '▲ Réduire';
			}
		else {		
			if (state == 'block') {
				vis.display = 'none';
				document.getElementById(imageID).value = '▼ Agrandir';
				}	
			else {
				vis.display = 'block'; 
				document.getElementById(imageID).value = '▲ Réduire';
				}
		}}

		//-->
	</script>

	<script type="text/javascript">
	// <![CDATA[
		var jump_page = '{LA_JUMP_PAGE}:';
		var on_page = '{ON_PAGE}';
		var per_page = '{PER_PAGE}';
		var base_url = '{A_BASE_URL}';
		var style_cookie = 'phpBBstyle';
		var style_cookie_settings = '{A_COOKIE_SETTINGS}';
		var onload_functions = new Array();
		var onunload_functions = new Array();

		/**
		* Find a member
		*/
		function find_username(url)
		{
			popup(url, 760, 570, '_usersearch');
			return false;
		}

		/**
		* New function for handling multiple calls to window.onload and window.unload by pentapenguin
		*/
		window.onload = function()
		{
			for (var i = 0; i < onload_functions.length; i++)
			{
				eval(onload_functions[i]);
			}
		}

		window.onunload = function()
		{
			for (var i = 0; i < onunload_functions.length; i++)
			{
				eval(onunload_functions[i]);
			}
		}

	// ]]>
	</script>

	<script type="text/javascript" src="http://html.net/forums/styles/prosilver/template/forum_fn.js"></script>

	<script type="text/javascript">

	  var _gaq = _gaq || [];
	  _gaq.push(['_setAccount', 'UA-6716118-1']);
	  _gaq.push(['_setDomainName', '.html.net']);
	  _gaq.push(['_trackPageview']);

	  (function() {
		var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	  })();

	</script>

	
</head>

<body>	

	<div id="login">
		
		<div><a href='/forums/ucp.php?mode=login'>Connexion</a> | <a href='/forums/ucp.php?mode=register'>Inscription</a> | <a href='/forums/faq.php'>FAQ</a></div><img src='/site/graphics/user.png' />		
	</div>

	<div id="header">
			
		<ul>
			<li><a href='/'>Accueil</a></li>
			<li class='selected'><a href='/tutorials/'>Tutoriels</a></li>
			<li><a href='/forums/'>Forums</a></li>
			<li><a href='/about/'>À propos</a></li>
		</ul>
		<form method="get" action="/search/" id="cse-search-box">
		<div id="searchbar">
			<span>
			
				<input type="text" name="q" id="query" value="" /><input type="submit" id="submit" value="Rechercher" />
				 <input type="hidden" name="cx" value="002160260272865772965:d4fb4jd-jh0" />
				<input type="hidden" name="cof" value="FORID:11;NB:1" />
				<input type="hidden" name="ie" value="UTF-8" />	
				<input type="hidden" name="lr" value="lang_fr" />	
				<input type="hidden" name="hl" value="fr" />	
			
			</span>
		</div>
		</form>
		
		<div id="ad_leaderboard">
	<script type='text/javascript' src='http://partner.googleadservices.com/gampad/google_service.js'>
	</script>
	<script type='text/javascript'>
	GS_googleAddAdSenseService("ca-pub-0941946313210493");
	GS_googleEnableAllServices();
	</script>
	<script type='text/javascript'>
	GA_googleAddSlot("ca-pub-0941946313210493", "HTML_NET_fr_tutorials_Leaderboard_728x90");
	</script>
	<script type='text/javascript'>
	GA_googleFetchAds();
	</script>

	<!-- ca-pub-0941946313210493/HTML_NET_fr_tutorials_Leaderboard_728x90 -->
	<script type='text/javascript'>
	GA_googleFillSlot("HTML_NET_fr_tutorials_Leaderboard_728x90");
	</script>
</div>

	</div>

	
		<div id="main">
		<div id="content">
			<div id="breadcrumb"><a href='/'>Accueil</a> &#187; <a href='/tutorials/'>Tutoriels</a> &#187; Tutoriel CSS - Table des matières</div>
			<div id="socialBookmarks">
				<a href="http://twitter.com/share" class="twitter-share-button" data-count="horizontal"></a>
				<span id="FbCont"></span>
				<g:plusone size="medium"></g:plusone>
								
			</div>
			<!-- google_ad_section_start -->
		
		<div id='tutorials'>	<h1>Tutoriel CSS - Table des matières</h1>

	<ul class="toc">
		<li><a href="introduction.php">Introduction</a><br />
		Une brève présentation du tutoriel et ce que vous allez y apprendre.</li>

		<li><a href="lesson1.php">Leçon 1 : Qu'est-ce que CSS ?</a><br />
		Une petite histoire de la création de CSS, et les raisons pour lesquelles il est judicieux de préférer CSS à HTML pour la disposition et la présentation.</li>

		<li><a href="lesson2.php">Leçon 2 : Comment CSS fonctionne-t-il ?</a><br />
		Apprendre la syntaxe de base de CSS et créer sa première feuille de style.</li>

		<li><a href="lesson3.php">Leçon 3 : Les couleurs et les arrières-plans</a><br />
		Apprendre à appliquer des couleurs et couleurs de fonds dans son site Web et comment utiliser des images d'arrière-plan.</li>

		<li><a href="lesson4.php">Leçon 4 : Les polices</a><br />
		Dans cette leçon, vous apprendrez ce que sont les polices et comment les appliquer avec CSS.</li>

		<li><a href="lesson5.php">Leçon 5 : Le texte</a><br />
		Cette leçon introduit les possibilités étonnantes de CSS pour ajouter une présentation au texte.</li>

		<li><a href="lesson6.php">Leçon 6 : Les liens</a><br />
		Comment ajouter des effets plaisants et utiles aux liens et se servir des pseudo-classes.</li>

		<li><a href="lesson7.php">Leçon 7 : L'identification et le regroupement d'éléments (class et id)</a><br />
		Une approche sur la façon d'utiliser les attributs <code>class</code> et <code>id</code> pour définir les propriétés des éléments sélectionnés.</li>

		<li><a href="lesson8.php">Leçon 8 : Le regroupement d'éléments (span et div)</a><br />
		Une approche de l'utilisation des éléments <code>span</code> et <code>div</code>, et le rôle central de ces deux éléments HTML pour CSS.</li>

		<li><a href="lesson9.php">Leçon 9 : Le modèle des boîtes</a><br />
		Le modèle des boîtes dans CSS décrit les boîtes générées pour les éléments HTML.</li>

		<li><a href="lesson10.php">Leçon 10 : Le modèle des boîtes : margin &amp; padding</a><br />
		Changer la présentation des éléments avec les propriétés <code>margin</code> et <code>padding</code>.</li>

		<li><a href="lesson11.php">Leçon 11 : Le modèle des boîtes : les bordures</a><br />
		Apprendre les options illimitées de l'utilisation de bordures dans ses pages avec CSS.</li>

		<li><a href="lesson12.php">Leçon 12 : Le modèle des boîtes : la hauteur et la largeur</a><br />
		Dans cette leçon, nous apprendrons comment définir aisément la hauteur et la largeur d'un élément.</li>

		<li><a href="lesson13.php">Leçon 13 : Les éléments flottants (les flottants)</a><br />
		Un élément peut flotter à droite ou à gauche avec la propriété <code>float</code>.</li>

		<li><a href="lesson14.php">Leçon 14 : Le positionnement des éléments</a><br />
		Le positionnement CSS permet de placer un élément dans la page exactement où l'on veut.</li>

		<li><a href="lesson15.php">Leçon 15 : Une couche sur une couche avec z-index (les couches)</a><br />
		Cette leçon nous apprendra comment faire se recouvrir des éléments différents avec la propriété <code>z-index</code>.</li>

		<li><a href="lesson16.php">Leçon 16 : Les standards du Web et la validation</a><br />
		La dernière leçon traite des standards du W3C et de la façon de vérifier l'exactitude de son code CSS.</li>
	</ul>
	<hr /><div id="ad_rectangle">
	<!--
	<span style="margin-right:10px;float:left">
	-->
	<span>
		<script type='text/javascript' src='http://partner.googleadservices.com/gampad/google_service.js'>
		</script>
		<script type='text/javascript'>
		GS_googleAddAdSenseService("ca-pub-0941946313210493");
		GS_googleEnableAllServices();
		</script>
		<script type='text/javascript'>
		GA_googleAddSlot("ca-pub-0941946313210493", "HTML_NET_fr_tutorials_LargeRectangle_336x280");
		</script>
		<script type='text/javascript'>
		GA_googleFetchAds();
		</script>

		<!-- ca-pub-0941946313210493/HTML_NET_fr_tutorials_LargeRectangle_336x280 -->
		<script type='text/javascript'>
		GA_googleFillSlot("HTML_NET_fr_tutorials_LargeRectangle_336x280");
		</script>
	</span>

	
</div><hr /><p class='next'><a href='introduction.php'>Introduction >></a></p></div>  		<!-- google_ad_section_end -->

		</div>

		<div id="ad_skyscraper">
	<script type='text/javascript' src='http://partner.googleadservices.com/gampad/google_service.js'>
	</script>
	<script type='text/javascript'>
	GS_googleAddAdSenseService("ca-pub-0941946313210493");
	GS_googleEnableAllServices();
	</script>
	<script type='text/javascript'>
	GA_googleAddSlot("ca-pub-0941946313210493", "HTML_NET_fr_tutorials_WideSkyscraper_160x600");
	</script>
	<script type='text/javascript'>
	GA_googleFetchAds();
	</script>

	<!-- ca-pub-0941946313210493/HTML_NET_fr_tutorials_WideSkyscraper_160x600 -->
	<script type='text/javascript'>
	GA_googleFillSlot("HTML_NET_fr_tutorials_WideSkyscraper_160x600");
	</script>

</div>




	</div>

	<div id="sidebar">
					<h1>Tutoriels</h1>
			<ul>
			<li><a href='/tutorials/html/'>Tutoriel HTML</a></li><li><strong><a href='/tutorials/css/'>Tutoriel CSS</a></strong><ul><li><a href='/tutorials/css/introduction.php'>Introduction</a></li><li><a href='/tutorials/css/lesson1.php'>Qu'est-ce que CSS ?</a></li><li><a href='/tutorials/css/lesson2.php'>Comment CSS fonctionne-t-il ?</a></li><li><a href='/tutorials/css/lesson3.php'>Les couleurs et les arrières-plans</a></li><li><a href='/tutorials/css/lesson4.php'>Les polices</a></li><li><a href='/tutorials/css/lesson5.php'>Le texte</a></li><li><a href='/tutorials/css/lesson6.php'>Les liens</a></li><li><a href='/tutorials/css/lesson7.php'>L'identification et le regroupement d'éléments (class et id)</a></li><li><a href='/tutorials/css/lesson8.php'>Le regroupement d'éléments (span et div)</a></li><li><a href='/tutorials/css/lesson9.php'>Le modèle des boîtes</a></li><li><a href='/tutorials/css/lesson10.php'>Le modèle des boîtes : margin & padding</a></li><li><a href='/tutorials/css/lesson11.php'>Le modèle des boîtes : les bordures</a></li><li><a href='/tutorials/css/lesson12.php'>Le modèle des boîtes : la hauteur et la largeur</a></li><li><a href='/tutorials/css/lesson13.php'>Les éléments flottants (les flottants)</a></li><li><a href='/tutorials/css/lesson14.php'>Le positionnement des éléments</a></li><li><a href='/tutorials/css/lesson15.php'>Une couche sur une couche avec z-index (les couches)</a></li><li><a href='/tutorials/css/lesson16.php'>Les standards du Web et la validation</a></li></ul></li><li><a href='/tutorials/php/'>Tutoriel PHP</a></li>			</ul>
			
		<!-- google_ad_section_start(weight=ignore) -->
		<h2>Langue</h2>
		
		<form method="post" action="/redirect.php">
			<p>
			<select name="location">
				
				<option value='http://ar.html.net/tutorials/css/index.php'>العربية</option>
				<option value='http://de.html.net/tutorials/css/index.php'>Deutsch</option>
				<option value='http://html.net/tutorials/css/index.php'>English</option>
				<option value='http://es.html.net/tutorials/css/index.php'>Español</option>
				<option selected='selected' value='http://fr.html.net/tutorials/css/index.php'>Français</option>
				<option value='http://he.html.net/tutorials/css/index.php'>עברית</option>
				<option value='http://it.html.net/tutorials/css/index.php'>Italiano</option>
				<option value='http://pl.html.net/tutorials/css/index.php'>Polski</option>
				<option value='http://pt-br.html.net/tutorials/css/index.php'>Português (Brasil)</option>
				<option value='http://ru.html.net/tutorials/css/index.php'>Русский</option>
				<option value='http://zh.html.net/tutorials/css/index.php'>中文</option>			</select>
			<input type="submit" value=">>" />
			</p>
		</form>
		
		
		<h2>La présentation</h2>
		<form method='post' action='http://fr.html.net/tutorials/css/index.php'>			<p>
			<select name="strCSS">
				
				<option value='1'>Default</option>
				<option value='2'>Default - Blue</option>
				<option value='3'>No CSS</option>			</select>
			<input type="submit" value=">>" />
			</p>
		</form>

		<h2>Traducteur:</h2> <p><a href='http://www.yoyodesign.org/scripts/message.php'>Jean Jacques Solari</a></p>
		
			

		

	</div>

	<div id="footer">

		<hr />

		
		<h1>Qui est en ligne ?:</h1>
		<p>Au total, il y a <strong>183</strong> utilisateurs en ligne :: 2 inscrits, 0 invisible et 181 invités</p> 
		<p>Le nombre maximum d’utilisateurs en ligne simultanément a été de <strong>338</strong> le Mar Sep 28, 2010 9:13 am</p> 
		<p id="userlist"><br />Utilisateurs inscrits : <span style="color: #9E8DA7;" class="username-coloured">Google [Bot]</span>, <span style="color: #9E8DA7;" class="username-coloured">Google Adsense [Bot]</span></p>
		
		<h1>Statistiques:</h1>
		<p>Messages au total <strong>6247</strong> - <strong>2592</strong> sujets au total</p><p><strong>6795</strong> membres au total - Notre membre le plus récent est <strong><a href='/forums/memberlist.php?mode=viewprofile&amp;u=9869'>Hsd265gbu7</a></strong></p>
		<p><br /><a href="/forums/memberlist.php">Visualiser la liste complète des membres</a></p>
		

		<h1>Langue:</h1>
		<p><span>
		<a href='http://ar.html.net/tutorials/css/index.php'>العربية</a> | <a href='http://de.html.net/tutorials/css/index.php'>Deutsch</a> | <a href='http://html.net/tutorials/css/index.php'>English</a> | <a href='http://es.html.net/tutorials/css/index.php'>Español</a> | Français | <a href='http://he.html.net/tutorials/css/index.php'>עברית</a> | <a href='http://it.html.net/tutorials/css/index.php'>Italiano</a> | <a href='http://pl.html.net/tutorials/css/index.php'>Polski</a> | <a href='http://pt-br.html.net/tutorials/css/index.php'>Português (Brasil)</a> | <a href='http://ru.html.net/tutorials/css/index.php'>Русский</a> | <a href='http://zh.html.net/tutorials/css/index.php'>中文</a> | 		</span></p>

		
	</div>

	<!-- google_ad_section_end -->

<script type='text/javascript' language='Javascript' src='http://s1.lqcdn.com/m.min.js?dt=2.3.110104.1'></script>
	
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>
<script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
<script src="http://connect.facebook.net/en_US/all.js#xfbml=1" type="text/javascript"></script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
var fb = document.createElement('fb:like'); 
fb.setAttribute("href",""); 
fb.setAttribute("layout","button_count");
fb.setAttribute("show_faces","false");
fb.setAttribute("width","");
fb.setAttribute("style","position:relative; top:-3px;");
document.getElementById("FbCont").appendChild(fb);
//--><!]]>
</script>


</body>
</html>
