<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<title>Exemple | Tutoriel CSS | HTML.net</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link rel="stylesheet" href="/tutorials/css/lesson14_ex1.css" type="text/css" media="all" />
</head>
<body>
	<div id="box1">
	Boîte 1
	</div>

	<div id="box2">
	Boîte 2
	</div>

	<div id="box3">
	Boîte 3
	</div>

	<div id="box4">
	Boîte 4
	</div>	
	</body>
</html>