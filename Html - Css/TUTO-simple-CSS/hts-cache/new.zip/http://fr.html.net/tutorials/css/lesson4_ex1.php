<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<title>Exemple | Tutoriel CSS | HTML.net</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link rel="stylesheet" href="/tutorials/css/lesson4_ex1.css" type="text/css" media="all" />
</head>
<body>
	<h1>Titre 1 dans la police Arial</h1>

	<h2>Et titre 2 dans la police Times New Roman</h2>
	
	</body>
</html>