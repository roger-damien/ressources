
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>

	<title>Leçon 1: Qu'est-ce que CSS ? - HTML.net</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="title" content="Leçon 1: Qu'est-ce que CSS ? - HTML.net" />
	<meta name="description" content="Leçon 1: Qu'est-ce que CSS ? - Tutoriels sur HTML et CSS - Construisez votre propre site Web" />
	<meta name="keywords" content="HTML, CSS, XHTML, Tutoriel HTML, Tutoriel CSS, Forums, , " />
	<meta name="language" content="fr" />
	<meta name="robots" content="index, follow" />
	<meta http-equiv="PICS-Label" content='(PICS-1.1 "http://www.classify.org/safesurf/" l gen true for "http://html.net/" r (SS~~000 1))' />
	<meta http-equiv="PICS-Label" content='(PICS-1.1 "http://www.icra.org/ratingsv02.html" l gen true for "http://html.net" r (cz 1 lz 1 nz 1 oz 1 vz 1) "http://www.rsac.org/ratingsv01.html" l gen true for "http://html.net" r (n 0 s 0 v 0 l 0))' /> 
	<meta property="og:title" content="Leçon 1: Qu'est-ce que CSS ? - HTML.net" />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="http://fr.html.net/tutorials/css/lesson1.php" />
	<meta property="og:image" content="http://html.net/avatar.png" />
	<meta property="og:site_name" content="HTML.net" />
	<meta property="fb:admins" content="610699221" />
	<link rel='stylesheet' href='http://html.net/site/style/default.screen.css' type='text/css' media='screen' /><link rel='stylesheet' href='http://html.net/site/style/default.print.css' type='text/css' media='print' />
	<script type="text/javascript">
			
		function toggleVisibility(objectID, imageID) {
		vis = document.getElementById(objectID).style;
		state = vis.display;
		if (state == 'none') {
			vis.display = 'block';	
			document.getElementById(imageID).value = '▲ Réduire';
			}
		else {		
			if (state == 'block') {
				vis.display = 'none';
				document.getElementById(imageID).value = '▼ Agrandir';
				}	
			else {
				vis.display = 'block'; 
				document.getElementById(imageID).value = '▲ Réduire';
				}
		}}

		//-->
	</script>

	<script type="text/javascript">
	// <![CDATA[
		var jump_page = '{LA_JUMP_PAGE}:';
		var on_page = '{ON_PAGE}';
		var per_page = '{PER_PAGE}';
		var base_url = '{A_BASE_URL}';
		var style_cookie = 'phpBBstyle';
		var style_cookie_settings = '{A_COOKIE_SETTINGS}';
		var onload_functions = new Array();
		var onunload_functions = new Array();

		/**
		* Find a member
		*/
		function find_username(url)
		{
			popup(url, 760, 570, '_usersearch');
			return false;
		}

		/**
		* New function for handling multiple calls to window.onload and window.unload by pentapenguin
		*/
		window.onload = function()
		{
			for (var i = 0; i < onload_functions.length; i++)
			{
				eval(onload_functions[i]);
			}
		}

		window.onunload = function()
		{
			for (var i = 0; i < onunload_functions.length; i++)
			{
				eval(onunload_functions[i]);
			}
		}

	// ]]>
	</script>

	<script type="text/javascript" src="http://html.net/forums/styles/prosilver/template/forum_fn.js"></script>

	<script type="text/javascript">

	  var _gaq = _gaq || [];
	  _gaq.push(['_setAccount', 'UA-6716118-1']);
	  _gaq.push(['_setDomainName', '.html.net']);
	  _gaq.push(['_trackPageview']);

	  (function() {
		var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	  })();

	</script>

	
</head>

<body>	

	<div id="login">
		
		<div><a href='/forums/ucp.php?mode=login'>Connexion</a> | <a href='/forums/ucp.php?mode=register'>Inscription</a> | <a href='/forums/faq.php'>FAQ</a></div><img src='/site/graphics/user.png' />		
	</div>

	<div id="header">
			
		<ul>
			<li><a href='/'>Accueil</a></li>
			<li class='selected'><a href='/tutorials/'>Tutoriels</a></li>
			<li><a href='/forums/'>Forums</a></li>
			<li><a href='/about/'>À propos</a></li>
		</ul>
		<form method="get" action="/search/" id="cse-search-box">
		<div id="searchbar">
			<span>
			
				<input type="text" name="q" id="query" value="" /><input type="submit" id="submit" value="Rechercher" />
				 <input type="hidden" name="cx" value="002160260272865772965:d4fb4jd-jh0" />
				<input type="hidden" name="cof" value="FORID:11;NB:1" />
				<input type="hidden" name="ie" value="UTF-8" />	
				<input type="hidden" name="lr" value="lang_fr" />	
				<input type="hidden" name="hl" value="fr" />	
			
			</span>
		</div>
		</form>
		
		<div id="ad_leaderboard">
	<script type='text/javascript' src='http://partner.googleadservices.com/gampad/google_service.js'>
	</script>
	<script type='text/javascript'>
	GS_googleAddAdSenseService("ca-pub-0941946313210493");
	GS_googleEnableAllServices();
	</script>
	<script type='text/javascript'>
	GA_googleAddSlot("ca-pub-0941946313210493", "HTML_NET_fr_tutorials_Leaderboard_728x90");
	</script>
	<script type='text/javascript'>
	GA_googleFetchAds();
	</script>

	<!-- ca-pub-0941946313210493/HTML_NET_fr_tutorials_Leaderboard_728x90 -->
	<script type='text/javascript'>
	GA_googleFillSlot("HTML_NET_fr_tutorials_Leaderboard_728x90");
	</script>
</div>

	</div>

	
		<div id="main">
		<div id="content">
			<div id="breadcrumb"><a href='/'>Accueil</a> &#187; <a href='/tutorials/'>Tutoriels</a> &#187; <a href='/tutorials/css/'>CSS</a> &#187; Leçon 1: Qu'est-ce que CSS ?</div>
			<div id="socialBookmarks">
				<a href="http://twitter.com/share" class="twitter-share-button" data-count="horizontal"></a>
				<span id="FbCont"></span>
				<g:plusone size="medium"></g:plusone>
								
			</div>
			<!-- google_ad_section_start -->
		
		<div id='tutorials'>	<h1>Leçon 1 : Qu'est-ce que CSS ?</h1>

	<p>Peut-être avez-vous déjà entendu parler de CSS sans vraiment savoir de quoi il s'agissait ? Dans cette leçon, vous en saurez plus
	sur CSS et sur ce que vous pouvez en tirer.</p>

	<p>CSS est l'abréviation de « <b>C</b>ascading <b>S</b>tyle <b>S</b>heets ».</p>

	<h2>Qu'est-ce qu'on peut faire avec CSS ?</h2>

	<p>CSS est un langage de style qui définit la présentation des documents HTML. Par exemple, CSS couvre les polices, les couleurs,
	les marges, les lignes, la hauteur, la largeur, les images d'arrière-plan, les positionnements évolués et bien d'autres choses.
	Attendez de voir !</p>

	<p>HTML peut être (mal)utilisé pour la présentation des sites Web. Mais CSS offre plus d'options et se montre plus précis et sophistiqué.
	CSS est pris en charge par tous les navigateurs actuels.</p>

	<p>Après seulement quelques leçons dans ce tutoriel, vous pourrez fabriquer vos propres feuilles de style avec CSS pour donner
	un aspect tout nouveau à votre site Web.</p>

	<h2>Quelle est la différence entre CSS et HTML ?</h2>

	<p>HTML sert à structurer le contenu, CSS sert à formater un contenu structuré.</p>

	<p>Bon, ça sonne un peu technique et confus. Mais continuez à lire, ça prendra tout son sens bientôt.</p>

	<p>Retour au bon vieux temps où Madonna était une vierge et un type nommé Tim Berners Lee inventait le World Wide Web, le langage HTML
	était seulement utilisé pour structurer du texte. Un auteur pouvait marquer son texte en déclarant &quot;voici un titre&quot;
	ou &quot;voici un paragraphe&quot;, avec les balises HTML <code>&lt;h1&gt;</code>, ou <code>&lt;p&gt;</code>.</p>

	<p>La popularité du Web croissant, les concepteurs se mirent à rechercher des moyens pour ajouter de la présentation
	aux documents en ligne. Pour satisfaire à cette demande, les éditeurs de navigateurs (en ce temps-là, Netscape et Microsoft)
	inventèrent de nouvelles balises HTML, comme par exemple <code>&lt;font&gt;</code>, qui différaient des éléments originaux
	en cela qu'ils définissaient une présentation et non une structure.</p>

	<p>Cela conduisit aussi à une situation où les balises de structure originales, telle que &lt;table&gt;, étaient de plus en plus
	utilisées à tort pour présenter les pages et non pour ajouter une structure au texte. Beaucoup de nouvelles balises de présentation,
	telle que &lt;blink&gt;, n'étaient reconnues que par un type de navigateur. &quot;Vous devez utiliser le navigateur X pour voir cette page&quot;
	devint un avertissement courant sur les sites Web.</p>

	<p>CSS fut inventé pour remédier à cette situation en offrant aux concepteurs Web des possibilités de présentations sophistiquées,
	gérées par tous les navigateurs. En même temps, séparer le style de présentation des documents de leur contenu rend leur entretien
	beaucoup plus facile. </p>

	<h2>Quels sont les avantages de CSS ?</h2>

	<p>CSS fut une révolution dans l'univers de la conception Web. Les avantages concrets de CSS sont les suivants :</p>

	<ul>
		<li>Le contrôle de la présentation de plusieurs documents par une seule feuille de style ;</li>
		<li>Un contrôle plus précis de la présentation ;</li>
		<li>Des présentations différentes appliquées à des types de médias différents (à l'écran, à l'impression, etc.) ;</li>
		<li>De nombreuses techniques évoluées et sophistiquées.</li>
	</ul>

	<p>Dans la <a href="lesson2.php">leçon suivante</a>, nous verrons comment CSS fonctionne réellement et comment commencer.</p>

	<hr /><div id="ad_rectangle">
	<!--
	<span style="margin-right:10px;float:left">
	-->
	<span>
		<script type='text/javascript' src='http://partner.googleadservices.com/gampad/google_service.js'>
		</script>
		<script type='text/javascript'>
		GS_googleAddAdSenseService("ca-pub-0941946313210493");
		GS_googleEnableAllServices();
		</script>
		<script type='text/javascript'>
		GA_googleAddSlot("ca-pub-0941946313210493", "HTML_NET_fr_tutorials_LargeRectangle_336x280");
		</script>
		<script type='text/javascript'>
		GA_googleFetchAds();
		</script>

		<!-- ca-pub-0941946313210493/HTML_NET_fr_tutorials_LargeRectangle_336x280 -->
		<script type='text/javascript'>
		GA_googleFillSlot("HTML_NET_fr_tutorials_LargeRectangle_336x280");
		</script>
	</span>

	
</div><hr /><p class='previous'><a href='introduction.php'>&lt;&lt; Introduction</a></p><p class='next'><a href='lesson2.php'>Leçon 2: Comment CSS fonctionne-t-il ? >></a></p></div>  		<!-- google_ad_section_end -->

		</div>

		<div id="ad_skyscraper">
	<script type='text/javascript' src='http://partner.googleadservices.com/gampad/google_service.js'>
	</script>
	<script type='text/javascript'>
	GS_googleAddAdSenseService("ca-pub-0941946313210493");
	GS_googleEnableAllServices();
	</script>
	<script type='text/javascript'>
	GA_googleAddSlot("ca-pub-0941946313210493", "HTML_NET_fr_tutorials_WideSkyscraper_160x600");
	</script>
	<script type='text/javascript'>
	GA_googleFetchAds();
	</script>

	<!-- ca-pub-0941946313210493/HTML_NET_fr_tutorials_WideSkyscraper_160x600 -->
	<script type='text/javascript'>
	GA_googleFillSlot("HTML_NET_fr_tutorials_WideSkyscraper_160x600");
	</script>

</div>




	</div>

	<div id="sidebar">
					<h1>Tutoriels</h1>
			<ul>
			<li><a href='/tutorials/html/'>Tutoriel HTML</a></li><li><strong><a href='/tutorials/css/'>Tutoriel CSS</a></strong><ul><li><a href='/tutorials/css/introduction.php'>Introduction</a></li><li class='selected'><a href='/tutorials/css/lesson1.php'>Qu'est-ce que CSS ?</a></li><li><a href='/tutorials/css/lesson2.php'>Comment CSS fonctionne-t-il ?</a></li><li><a href='/tutorials/css/lesson3.php'>Les couleurs et les arrières-plans</a></li><li><a href='/tutorials/css/lesson4.php'>Les polices</a></li><li><a href='/tutorials/css/lesson5.php'>Le texte</a></li><li><a href='/tutorials/css/lesson6.php'>Les liens</a></li><li><a href='/tutorials/css/lesson7.php'>L'identification et le regroupement d'éléments (class et id)</a></li><li><a href='/tutorials/css/lesson8.php'>Le regroupement d'éléments (span et div)</a></li><li><a href='/tutorials/css/lesson9.php'>Le modèle des boîtes</a></li><li><a href='/tutorials/css/lesson10.php'>Le modèle des boîtes : margin & padding</a></li><li><a href='/tutorials/css/lesson11.php'>Le modèle des boîtes : les bordures</a></li><li><a href='/tutorials/css/lesson12.php'>Le modèle des boîtes : la hauteur et la largeur</a></li><li><a href='/tutorials/css/lesson13.php'>Les éléments flottants (les flottants)</a></li><li><a href='/tutorials/css/lesson14.php'>Le positionnement des éléments</a></li><li><a href='/tutorials/css/lesson15.php'>Une couche sur une couche avec z-index (les couches)</a></li><li><a href='/tutorials/css/lesson16.php'>Les standards du Web et la validation</a></li></ul></li><li><a href='/tutorials/php/'>Tutoriel PHP</a></li>			</ul>
			
		<!-- google_ad_section_start(weight=ignore) -->
		<h2>Langue</h2>
		
		<form method="post" action="/redirect.php">
			<p>
			<select name="location">
				
				<option value='http://ar.html.net/tutorials/css/lesson1.php'>العربية</option>
				<option value='http://de.html.net/tutorials/css/lesson1.php'>Deutsch</option>
				<option value='http://html.net/tutorials/css/lesson1.php'>English</option>
				<option value='http://es.html.net/tutorials/css/lesson1.php'>Español</option>
				<option selected='selected' value='http://fr.html.net/tutorials/css/lesson1.php'>Français</option>
				<option value='http://he.html.net/tutorials/css/lesson1.php'>עברית</option>
				<option value='http://it.html.net/tutorials/css/lesson1.php'>Italiano</option>
				<option value='http://pl.html.net/tutorials/css/lesson1.php'>Polski</option>
				<option value='http://pt-br.html.net/tutorials/css/lesson1.php'>Português (Brasil)</option>
				<option value='http://ru.html.net/tutorials/css/lesson1.php'>Русский</option>
				<option value='http://zh.html.net/tutorials/css/lesson1.php'>中文</option>			</select>
			<input type="submit" value=">>" />
			</p>
		</form>
		
		
		<h2>La présentation</h2>
		<form method='post' action='http://fr.html.net/tutorials/css/lesson1.php'>			<p>
			<select name="strCSS">
				
				<option value='1'>Default</option>
				<option value='2'>Default - Blue</option>
				<option value='3'>No CSS</option>			</select>
			<input type="submit" value=">>" />
			</p>
		</form>

		<h2>Traducteur:</h2> <p><a href='http://www.yoyodesign.org/scripts/message.php'>Jean Jacques Solari</a></p>
		
			

		

	</div>

	<div id="footer">

		<hr />

		
		<h1>Qui est en ligne ?:</h1>
		<p>Au total, il y a <strong>170</strong> utilisateurs en ligne :: 2 inscrits, 0 invisible et 168 invités</p> 
		<p>Le nombre maximum d’utilisateurs en ligne simultanément a été de <strong>338</strong> le Mar Sep 28, 2010 9:13 am</p> 
		<p id="userlist"><br />Utilisateurs inscrits : <span style="color: #9E8DA7;" class="username-coloured">Google [Bot]</span>, <span style="color: #9E8DA7;" class="username-coloured">Google Adsense [Bot]</span></p>
		
		<h1>Statistiques:</h1>
		<p>Messages au total <strong>6247</strong> - <strong>2592</strong> sujets au total</p><p><strong>6795</strong> membres au total - Notre membre le plus récent est <strong><a href='/forums/memberlist.php?mode=viewprofile&amp;u=9869'>Hsd265gbu7</a></strong></p>
		<p><br /><a href="/forums/memberlist.php">Visualiser la liste complète des membres</a></p>
		

		<h1>Langue:</h1>
		<p><span>
		<a href='http://ar.html.net/tutorials/css/lesson1.php'>العربية</a> | <a href='http://de.html.net/tutorials/css/lesson1.php'>Deutsch</a> | <a href='http://html.net/tutorials/css/lesson1.php'>English</a> | <a href='http://es.html.net/tutorials/css/lesson1.php'>Español</a> | Français | <a href='http://he.html.net/tutorials/css/lesson1.php'>עברית</a> | <a href='http://it.html.net/tutorials/css/lesson1.php'>Italiano</a> | <a href='http://pl.html.net/tutorials/css/lesson1.php'>Polski</a> | <a href='http://pt-br.html.net/tutorials/css/lesson1.php'>Português (Brasil)</a> | <a href='http://ru.html.net/tutorials/css/lesson1.php'>Русский</a> | <a href='http://zh.html.net/tutorials/css/lesson1.php'>中文</a> | 		</span></p>

		
	</div>

	<!-- google_ad_section_end -->

<script type='text/javascript' language='Javascript' src='http://s1.lqcdn.com/m.min.js?dt=2.3.110104.1'></script>
	
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>
<script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
<script src="http://connect.facebook.net/en_US/all.js#xfbml=1" type="text/javascript"></script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
var fb = document.createElement('fb:like'); 
fb.setAttribute("href",""); 
fb.setAttribute("layout","button_count");
fb.setAttribute("show_faces","false");
fb.setAttribute("width","");
fb.setAttribute("style","position:relative; top:-3px;");
document.getElementById("FbCont").appendChild(fb);
//--><!]]>
</script>


</body>
</html>
