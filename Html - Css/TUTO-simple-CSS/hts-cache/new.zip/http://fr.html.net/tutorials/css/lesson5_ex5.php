<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<title>Exemple | Tutoriel CSS | HTML.net</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link rel="stylesheet" href="/tutorials/css/lesson5_ex5.css" type="text/css" media="all" />
</head>
<body>
	<h1>ce titre est en majuscule</h1>

	<ul>
	<li>peter hanson</li>
	<li>max larson</li>
	<li>joe doe</li>
	<li>paula jones</li>
	<li>monica lewinsky</li>
	<li>donald duck</li>
	</ul>

	<p>Remarquez la capitalisation initiale des noms réalisée par CSS</p>
		
	</body>
</html>