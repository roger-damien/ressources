
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>

	<title>Leçon 3: Les couleurs et les arrières-plans - HTML.net</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="title" content="Leçon 3: Les couleurs et les arrières-plans - HTML.net" />
	<meta name="description" content="Leçon 3: Les couleurs et les arrières-plans - Tutoriels sur HTML et CSS - Construisez votre propre site Web" />
	<meta name="keywords" content="HTML, CSS, XHTML, Tutoriel HTML, Tutoriel CSS, Forums, , " />
	<meta name="language" content="fr" />
	<meta name="robots" content="index, follow" />
	<meta http-equiv="PICS-Label" content='(PICS-1.1 "http://www.classify.org/safesurf/" l gen true for "http://html.net/" r (SS~~000 1))' />
	<meta http-equiv="PICS-Label" content='(PICS-1.1 "http://www.icra.org/ratingsv02.html" l gen true for "http://html.net" r (cz 1 lz 1 nz 1 oz 1 vz 1) "http://www.rsac.org/ratingsv01.html" l gen true for "http://html.net" r (n 0 s 0 v 0 l 0))' /> 
	<meta property="og:title" content="Leçon 3: Les couleurs et les arrières-plans - HTML.net" />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="http://fr.html.net/tutorials/css/lesson3.php" />
	<meta property="og:image" content="http://html.net/avatar.png" />
	<meta property="og:site_name" content="HTML.net" />
	<meta property="fb:admins" content="610699221" />
	<link rel='stylesheet' href='http://html.net/site/style/default.screen.css' type='text/css' media='screen' /><link rel='stylesheet' href='http://html.net/site/style/default.print.css' type='text/css' media='print' />
	<script type="text/javascript">
			
		function toggleVisibility(objectID, imageID) {
		vis = document.getElementById(objectID).style;
		state = vis.display;
		if (state == 'none') {
			vis.display = 'block';	
			document.getElementById(imageID).value = '▲ Réduire';
			}
		else {		
			if (state == 'block') {
				vis.display = 'none';
				document.getElementById(imageID).value = '▼ Agrandir';
				}	
			else {
				vis.display = 'block'; 
				document.getElementById(imageID).value = '▲ Réduire';
				}
		}}

		//-->
	</script>

	<script type="text/javascript">
	// <![CDATA[
		var jump_page = '{LA_JUMP_PAGE}:';
		var on_page = '{ON_PAGE}';
		var per_page = '{PER_PAGE}';
		var base_url = '{A_BASE_URL}';
		var style_cookie = 'phpBBstyle';
		var style_cookie_settings = '{A_COOKIE_SETTINGS}';
		var onload_functions = new Array();
		var onunload_functions = new Array();

		/**
		* Find a member
		*/
		function find_username(url)
		{
			popup(url, 760, 570, '_usersearch');
			return false;
		}

		/**
		* New function for handling multiple calls to window.onload and window.unload by pentapenguin
		*/
		window.onload = function()
		{
			for (var i = 0; i < onload_functions.length; i++)
			{
				eval(onload_functions[i]);
			}
		}

		window.onunload = function()
		{
			for (var i = 0; i < onunload_functions.length; i++)
			{
				eval(onunload_functions[i]);
			}
		}

	// ]]>
	</script>

	<script type="text/javascript" src="http://html.net/forums/styles/prosilver/template/forum_fn.js"></script>

	<script type="text/javascript">

	  var _gaq = _gaq || [];
	  _gaq.push(['_setAccount', 'UA-6716118-1']);
	  _gaq.push(['_setDomainName', '.html.net']);
	  _gaq.push(['_trackPageview']);

	  (function() {
		var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	  })();

	</script>

	
</head>

<body>	

	<div id="login">
		
		<div><a href='/forums/ucp.php?mode=login'>Connexion</a> | <a href='/forums/ucp.php?mode=register'>Inscription</a> | <a href='/forums/faq.php'>FAQ</a></div><img src='/site/graphics/user.png' />		
	</div>

	<div id="header">
			
		<ul>
			<li><a href='/'>Accueil</a></li>
			<li class='selected'><a href='/tutorials/'>Tutoriels</a></li>
			<li><a href='/forums/'>Forums</a></li>
			<li><a href='/about/'>À propos</a></li>
		</ul>
		<form method="get" action="/search/" id="cse-search-box">
		<div id="searchbar">
			<span>
			
				<input type="text" name="q" id="query" value="" /><input type="submit" id="submit" value="Rechercher" />
				 <input type="hidden" name="cx" value="002160260272865772965:d4fb4jd-jh0" />
				<input type="hidden" name="cof" value="FORID:11;NB:1" />
				<input type="hidden" name="ie" value="UTF-8" />	
				<input type="hidden" name="lr" value="lang_fr" />	
				<input type="hidden" name="hl" value="fr" />	
			
			</span>
		</div>
		</form>
		
		<div id="ad_leaderboard">
	<script type='text/javascript' src='http://partner.googleadservices.com/gampad/google_service.js'>
	</script>
	<script type='text/javascript'>
	GS_googleAddAdSenseService("ca-pub-0941946313210493");
	GS_googleEnableAllServices();
	</script>
	<script type='text/javascript'>
	GA_googleAddSlot("ca-pub-0941946313210493", "HTML_NET_fr_tutorials_Leaderboard_728x90");
	</script>
	<script type='text/javascript'>
	GA_googleFetchAds();
	</script>

	<!-- ca-pub-0941946313210493/HTML_NET_fr_tutorials_Leaderboard_728x90 -->
	<script type='text/javascript'>
	GA_googleFillSlot("HTML_NET_fr_tutorials_Leaderboard_728x90");
	</script>
</div>

	</div>

	
		<div id="main">
		<div id="content">
			<div id="breadcrumb"><a href='/'>Accueil</a> &#187; <a href='/tutorials/'>Tutoriels</a> &#187; <a href='/tutorials/css/'>CSS</a> &#187; Leçon 3: Les couleurs et les arrières-plans</div>
			<div id="socialBookmarks">
				<a href="http://twitter.com/share" class="twitter-share-button" data-count="horizontal"></a>
				<span id="FbCont"></span>
				<g:plusone size="medium"></g:plusone>
								
			</div>
			<!-- google_ad_section_start -->
		
		<div id='tutorials'>	<h1>Leçon 3 : Les couleurs et les arrières-plans</h1>

	<p>Dans cette leçon, vous apprendrez comment appliquer des couleurs et des couleurs d'arrière-plan à vos sites Web.
	Nous étudierons également des méthodes évoluées pour positionner et contrôler les images d'arrière-plan. Les propriétés CSS suivantes
	seront expliquées :</p>

	<ul>
		<li><a href="#s1">color</a></li>
		<li><a href="#s2">background-color</a></li>
		<li><a href="#s3">background-image</a></li>
		<li><a href="#s4">background-repeat</a></li>
		<li><a href="#s5">background-attachment</a></li>
		<li><a href="#s6">background-position</a></li>
		<li><a href="#s7">background</a></li>
	</ul>

	<h2 id="s1">La couleur d'avant-plan : la propriété 'color'</h2>

	<p>La propriété <code>color</code> décrit la couleur d'avant-plan d'un élément.</p>
	<p>Par exemple, supposons que nous voulions tous les titres du document en rouge foncé. Les titres sont tous balisés avec l'élément HTML <code>&lt;h1&gt;</code>.
	Le code suivant donne aux éléments <code>&lt;h1&gt;</code> une couleur rouge.</p>

	<div class="codebox">
	<pre>
	<code>
	h1 {
		<strong>color: #ff0000;</strong>
	}
	</code>
	</pre>
	</div>

	<ul class="examplelinklist">
		<li><a href="lesson3_ex1.php" title="Illustrer le code précédent">Afficher un exemple</a></li>
	</ul>

	<p>On peut définir les couleurs avec des valeurs hexadécimales comme dans l'exemple précédent (#ff0000), ou avec les noms
	des couleurs (&quot;red&quot;), ou avec des valeurs RGB (rgb(255,0,0)).</p>

	<h2 id="s2">La propriété 'background-color'</h2>
	<p>La propriété <code>background-color</code> décrit la couleur d'arrière-plan des éléments.</p>
	<p>L'élément <code>&lt;body&gt;</code> est le réceptacle de tout le contenu du document HTML. Pour changer la couleur d'arrière-plan
	d'une page entière, il faudrait donc appliquer la propriété 'background-color' à l'élément <code>&lt;body&gt;</code>.</p>
	<p>On peut aussi appliquer une couleur d'arrière-plan à d'autres éléments y compris les titres et le texte. Dans l'exemple ci-dessous,
	Des couleurs d'arrière-plan différentes sont appliquées aux éléments <code>&lt;body&gt;</code> et <code>&lt;h1&gt;</code>.</p>

	<div class="codebox">
	<pre>
	<code>
	body {
		<strong>background-color: #FFCC66;</strong>
	}

	h1 {
		color: #990000;
		<strong>background-color: #FC9804;</strong>
	}
	</code>
	</pre>
	</div>

	<ul class="examplelinklist">
		<li><a href="lesson3_ex2.php" title="Illustrer le code précédent">Afficher un exemple</a></li>
	</ul>

	<p>Remarquez que nous avons appliqué deux propriétés à <code>&lt;h1&gt;</code> en les séparant par un point-virgule.</p>

	<h2 id="s3">Les images d'arrière-plan [background-image]</h2>
	<p>La propriété CSS <code>background-image</code> sert à insérer une image d'arrière-plan.</p>
	<p>Comme exemple d'image d'arrière-plan, nous utilisons le papillon ci-dessous. Vous pouvez télécharger l'image pour l'utiliser
	sur votre propre ordinateur (en cliquant sur le bouton de droite de la souris et en sélectionnant « Enregistrer l'image sous »,
	ou vous pouvez utiliser une autre image si vous voulez.</p>
	<p><img src="butterfly.gif" alt="Un papillon" /></p>
	<p>Pour insérer l'image du papillon en arrière-plan d'une page Web, appliquez simplement la propriété background-image
	à l'élément <code>&lt;body&gt;</code> et indiquez le chemin de l'image.</p>

	<div class="codebox">
	<pre>
	<code>
	body {
		background-color: #FFCC66;
		<strong>background-image: url(&quot;butterfly.gif&quot;);</strong>
	}

	h1 {
		color: #990000;
		background-color: #FC9804;
	}
	</code>
	</pre>
	</div>

	<ul class="examplelinklist">
		<li><a href="lesson3_ex3.php" title="Illustrer le code précédent">Afficher un exemple</a></li>
	</ul>

	<p>Remarquez la façon dont nous avons indiqué le chemin de l'image avec <strong>url(&quot;butterfly.gif&quot;)</strong>.
	Cela signifie que l'image se trouve dnas le même dossier que la feuille de style. On peut aussi appeler des images dans d'autres dossiers
	avec <strong>url(&quot;../images/butterfly.gif&quot;)</strong>, ou même sur Internet en donnant l'adresse complète du fichier :
	<strong>url(&quot;http://www.html.net/butterfly.gif&quot;)</strong>.</p>

	<h2 id="s4">Répéter l'image d'arrière-plan [background-repeat]</h2>
	<p>Avez-vous remarqué, dans l'exemple précédent, que le papillon était répété par défaut horizontalement et verticalement pour couvrir
	la totalité de l'écran ? Ce comportement est contrôlé par la propriété <code>background-repeat</code>.</p>
	<p>Le tableau suivant décrit les quatre valeurs différentes de <code>background-repeat</code>.</p>

	<table border="1">
	<tr><th>Valeur</th><th>Description</th><th>Exemple</th></tr>
	<tr><td><code>Background-repeat: repeat-x</code></td><td>L'image se répète horizontalement</td><td><a href="lesson3_ex4.php">Afficher un exemple</a></td></tr>
	<tr><td><code>background-repeat: repeat-y</code></td><td>L'image se répète verticalement</td><td><a href="lesson3_ex5.php">Afficher un exemple</a></td></tr>
	<tr><td><code>background-repeat: repeat</code></td><td>L'image se répète horizontalement et verticalement</td><td><a href="lesson3_ex6.php">Afficher un exemple</a></td></tr>
	<tr><td><code>background-repeat: no-repeat</code></td><td>L'image ne se répète pas</td><td><a href="lesson3_ex7.php">Afficher un exemple</a></td></tr>
	</table>
	<p>Par exemple, pour éviter la répétition d'une image d'arrière-plan, le code devrait ressembler à ceci :</p>

	<div class="codebox">
	<pre>
	<code>
	body {
		background-color: #FFCC66;
		background-image: url(&quot;butterfly.gif&quot;);
		<strong>background-repeat: no-repeat;</strong>
	}

	h1 {
		color: #990000;
		background-color: #FC9804;
	}
	</code>
	</pre>
	</div>


	<ul class="examplelinklist">
		<li><a href="lesson3_ex7.php" title="Illustrer le code précédent">Afficher un exemple</a></li>
	</ul>

	<h2 id="s5">Bloquer l'image d'arrière-plan [background-attachment]</h2>
	<p>La propriété <code>background-attachment</code> définit si l'image d'arrière-plan est fixe ou bien défile avec l'élément conteneur.</p>
	<p>Une image d'arrière-plan bloquée ne bougera pas avec le texte lorsque le lecteur fait défiler la page, au contraire d'une image d'arrière-plan
	non bloquée qui défilera avec le texte de la page Web.</p>
	<p>Le tableau suivant décrit les deux valeurs différentes de <code>background-attachment</code>. Cliquez sur les exemples
	pour voir la différence entre défiler et fixé.</p>

	<table border="1">
	<tr><th>Valeur</th><th>Description</th><th>Exemple</th></tr>
	<tr><td><code>Background-attachment: scroll</code></td><td>L'image défile avec la page (non bloquée)</td><td><a href="lesson3_ex8.php">Afficher un exemple</a></td></tr>
	<tr><td><code>Background-attachment: fixed</code></td><td>L'image est bloquée</td><td><a href="lesson3_ex9.php">Afficher un exemple</a></td></tr>
	</table>

	<p>Par exemple, le code suivant bloquera l'image d'arrière-plan.</p>

	<div class="codebox">
	<pre>
	<code>
	body {
		background-color: #FFCC66;
		background-image: url(&quot;butterfly.gif&quot;);
		background-repeat: no-repeat;
		<strong>background-attachment: fixed;</strong>
	}

	h1 {
		color: #990000;
		background-color: #FC9804;
	}
	</code>
	</pre>
	</div>

	<ul class="examplelinklist">
		<li><a href="lesson3_ex9.php">Afficher un exemple</a></li>
	</ul>

	<h2 id="s6">Positionner une image d'arrière-plan [background-position]</h2>
	<p>Par défaut, l'image d'arrière-plan se positionnera dans le coin supérieur gauche de l'écran. La propriété <code>background-position</code>
	permet de changer cette position prédéfinie et de placer l'image d'arrière-plan n'importe où à l'écran.</p>
	<p>Il y a plusieurs méthodes pour fixer la valeur de <code>background-position</code>. Par contre, elles se présentent toutes sous
	la forme d'un jeu de coordonnées. Par exemple, la valeur'100px 200px' positionne l'image d'arrière-plan à 100px depuis la gauche
	et à 200px depuis le haut de la fenêtre du navigateur.</p>
	<p>Les coordonnées peuvent s'exprimer en pourcentages de la largeur de l'écran, ou en unités fixes (pixels, centimètres, etc.),
	ou on peut utiliser les mots-clés "top", "bottom", "center", "left" ou "right". Le modèle suivant illustre ce système :</p>
	<p><img src="figure004.gif" alt="" /></p>

	<p><br />Le tableau suivant fournit quelques exemples.</p>

	<table border="1">
	<tr><th>Valeur</th><th>Description</th><th>Exemple</th></tr>
	<tr><td><code>background-position: 2cm 2cm</code></td><td>L'image est positionnée à 2 cm de la gauche et à 2 cm du haut de la page</td><td><a href="lesson3_ex10.php">Afficher un exemple</a></td></tr>
	<tr><td><code>background-position: 50% 25%</code></td><td>L'image est positionnée au centre et à un quart de la page vers le bas</td><td><a href="lesson3_ex11.php">Afficher un exemple</a></td></tr>
	<tr><td><code>background-position: top right</code></td><td>L'image est positionnée au coin supérieur droit de la page</td><td><a href="lesson3_ex12.php">Afficher un exemple</a></td></tr>
	</table>

	<p>L'exemple de code à suivre positionne l'image d'arrière-plan dans le coin inférieur droit de la page :</p>

	<div class="codebox">
	<pre>
	<code>
	body {
		background-color: #FFCC66;
		background-image: url(&quot;butterfly.gif&quot;);
		background-repeat: no-repeat;
		background-attachment: fixed;
		<strong>background-position: right bottom;</strong>
	}

	h1 {
		color: #990000;
		background-color: #FC9804;
	}
	</code>
	</pre>
	</div>

	<ul class="examplelinklist">
		<li><a href="lesson3_ex13.php">Afficher un exemple</a></li>
	</ul>

	<h2 id="s7">Concision [background]</h2>
	<p>La propriété <code>background</code> est un raccourci pour toutes les propriétés listées dans cette leçon.</p>
	<p>Avec <code>background</code>, on peut comprimer plusieurs propriétés et donc écrire une feuille de style plus courte,
	ce qui en facilite la lecture.</p>
	<p>Par exemple, les cinq lignes suivantes :</p>

	<div class="codebox">
	<pre>
	<code>
	background-color: #FFCC66;
	background-image: url(&quot;butterfly.gif&quot;);
	background-repeat: no-repeat;
	background-attachment: fixed;
	background-position: right bottom;
	</code>
	</pre>
	</div>

	<p>On peut obtenir le même résultat avec <code>background</code> en une seule ligne de code :</p>

	<div class="codebox">
	<pre>
	<code>
	background: #FFCC66 url(&quot;butterfly.gif&quot;) no-repeat fixed right bottom;
	</code>
	</pre>
	</div>

	<p>La liste de commande est la suivante :</p>
	<p><code>[background-color]</code> | <code>[background-image]</code> | <code>[background-repeat]</code> | <code>[background-attachment]</code> | <code>[background-position]</code></p>
	<p>Si une propriété manque, elle prend automatiquement sa valeur par défaut. Par exemple, si on supprime
	<code>background-attachment</code> et <code>background-position</code> de l'exemple :</p>

	<div class="codebox">
	<pre>
	<code>
	background: #FFCC66 url(&quot;butterfly.gif&quot;) no-repeat;
	</code>
	</pre>
	</div>

	<p>Ces deux propriété non définies prendront tout simplement leurs valeurs par défaut, qui sont comme chacun sait "scroll" et "top left".</p>

	<h2>Résumé</h2>
	<p>Dans cette leçon, vous avez déjà appris des techniques nouvelles qui seraient impossibles avec HTML. L'aventure continue dans la
	<a href="lesson4.php">leçon suivante</a> qui examine la large gamme de possibilités de CSS pour décrire les polices.</p>
	
	<hr /><div id="ad_rectangle">
	<!--
	<span style="margin-right:10px;float:left">
	-->
	<span>
		<script type='text/javascript' src='http://partner.googleadservices.com/gampad/google_service.js'>
		</script>
		<script type='text/javascript'>
		GS_googleAddAdSenseService("ca-pub-0941946313210493");
		GS_googleEnableAllServices();
		</script>
		<script type='text/javascript'>
		GA_googleAddSlot("ca-pub-0941946313210493", "HTML_NET_fr_tutorials_LargeRectangle_336x280");
		</script>
		<script type='text/javascript'>
		GA_googleFetchAds();
		</script>

		<!-- ca-pub-0941946313210493/HTML_NET_fr_tutorials_LargeRectangle_336x280 -->
		<script type='text/javascript'>
		GA_googleFillSlot("HTML_NET_fr_tutorials_LargeRectangle_336x280");
		</script>
	</span>

	
</div><hr /><p class='previous'><a href='lesson2.php'>&lt;&lt; Leçon 2: Comment CSS fonctionne-t-il ?</a></p><p class='next'><a href='lesson4.php'>Leçon 4: Les polices >></a></p></div>  		<!-- google_ad_section_end -->

		</div>

		<div id="ad_skyscraper">
	<script type='text/javascript' src='http://partner.googleadservices.com/gampad/google_service.js'>
	</script>
	<script type='text/javascript'>
	GS_googleAddAdSenseService("ca-pub-0941946313210493");
	GS_googleEnableAllServices();
	</script>
	<script type='text/javascript'>
	GA_googleAddSlot("ca-pub-0941946313210493", "HTML_NET_fr_tutorials_WideSkyscraper_160x600");
	</script>
	<script type='text/javascript'>
	GA_googleFetchAds();
	</script>

	<!-- ca-pub-0941946313210493/HTML_NET_fr_tutorials_WideSkyscraper_160x600 -->
	<script type='text/javascript'>
	GA_googleFillSlot("HTML_NET_fr_tutorials_WideSkyscraper_160x600");
	</script>

</div>




	</div>

	<div id="sidebar">
					<h1>Tutoriels</h1>
			<ul>
			<li><a href='/tutorials/html/'>Tutoriel HTML</a></li><li><strong><a href='/tutorials/css/'>Tutoriel CSS</a></strong><ul><li><a href='/tutorials/css/introduction.php'>Introduction</a></li><li><a href='/tutorials/css/lesson1.php'>Qu'est-ce que CSS ?</a></li><li><a href='/tutorials/css/lesson2.php'>Comment CSS fonctionne-t-il ?</a></li><li class='selected'><a href='/tutorials/css/lesson3.php'>Les couleurs et les arrières-plans</a></li><li><a href='/tutorials/css/lesson4.php'>Les polices</a></li><li><a href='/tutorials/css/lesson5.php'>Le texte</a></li><li><a href='/tutorials/css/lesson6.php'>Les liens</a></li><li><a href='/tutorials/css/lesson7.php'>L'identification et le regroupement d'éléments (class et id)</a></li><li><a href='/tutorials/css/lesson8.php'>Le regroupement d'éléments (span et div)</a></li><li><a href='/tutorials/css/lesson9.php'>Le modèle des boîtes</a></li><li><a href='/tutorials/css/lesson10.php'>Le modèle des boîtes : margin & padding</a></li><li><a href='/tutorials/css/lesson11.php'>Le modèle des boîtes : les bordures</a></li><li><a href='/tutorials/css/lesson12.php'>Le modèle des boîtes : la hauteur et la largeur</a></li><li><a href='/tutorials/css/lesson13.php'>Les éléments flottants (les flottants)</a></li><li><a href='/tutorials/css/lesson14.php'>Le positionnement des éléments</a></li><li><a href='/tutorials/css/lesson15.php'>Une couche sur une couche avec z-index (les couches)</a></li><li><a href='/tutorials/css/lesson16.php'>Les standards du Web et la validation</a></li></ul></li><li><a href='/tutorials/php/'>Tutoriel PHP</a></li>			</ul>
			
		<!-- google_ad_section_start(weight=ignore) -->
		<h2>Langue</h2>
		
		<form method="post" action="/redirect.php">
			<p>
			<select name="location">
				
				<option value='http://ar.html.net/tutorials/css/lesson3.php'>العربية</option>
				<option value='http://de.html.net/tutorials/css/lesson3.php'>Deutsch</option>
				<option value='http://html.net/tutorials/css/lesson3.php'>English</option>
				<option value='http://es.html.net/tutorials/css/lesson3.php'>Español</option>
				<option selected='selected' value='http://fr.html.net/tutorials/css/lesson3.php'>Français</option>
				<option value='http://he.html.net/tutorials/css/lesson3.php'>עברית</option>
				<option value='http://it.html.net/tutorials/css/lesson3.php'>Italiano</option>
				<option value='http://pl.html.net/tutorials/css/lesson3.php'>Polski</option>
				<option value='http://pt-br.html.net/tutorials/css/lesson3.php'>Português (Brasil)</option>
				<option value='http://ru.html.net/tutorials/css/lesson3.php'>Русский</option>
				<option value='http://zh.html.net/tutorials/css/lesson3.php'>中文</option>			</select>
			<input type="submit" value=">>" />
			</p>
		</form>
		
		
		<h2>La présentation</h2>
		<form method='post' action='http://fr.html.net/tutorials/css/lesson3.php'>			<p>
			<select name="strCSS">
				
				<option value='1'>Default</option>
				<option value='2'>Default - Blue</option>
				<option value='3'>No CSS</option>			</select>
			<input type="submit" value=">>" />
			</p>
		</form>

		<h2>Traducteur:</h2> <p><a href='http://www.yoyodesign.org/scripts/message.php'>Jean Jacques Solari</a></p>
		
			

		

	</div>

	<div id="footer">

		<hr />

		
		<h1>Qui est en ligne ?:</h1>
		<p>Au total, il y a <strong>170</strong> utilisateurs en ligne :: 2 inscrits, 0 invisible et 168 invités</p> 
		<p>Le nombre maximum d’utilisateurs en ligne simultanément a été de <strong>338</strong> le Mar Sep 28, 2010 9:13 am</p> 
		<p id="userlist"><br />Utilisateurs inscrits : <span style="color: #9E8DA7;" class="username-coloured">Google [Bot]</span>, <span style="color: #9E8DA7;" class="username-coloured">Google Adsense [Bot]</span></p>
		
		<h1>Statistiques:</h1>
		<p>Messages au total <strong>6247</strong> - <strong>2592</strong> sujets au total</p><p><strong>6795</strong> membres au total - Notre membre le plus récent est <strong><a href='/forums/memberlist.php?mode=viewprofile&amp;u=9869'>Hsd265gbu7</a></strong></p>
		<p><br /><a href="/forums/memberlist.php">Visualiser la liste complète des membres</a></p>
		

		<h1>Langue:</h1>
		<p><span>
		<a href='http://ar.html.net/tutorials/css/lesson3.php'>العربية</a> | <a href='http://de.html.net/tutorials/css/lesson3.php'>Deutsch</a> | <a href='http://html.net/tutorials/css/lesson3.php'>English</a> | <a href='http://es.html.net/tutorials/css/lesson3.php'>Español</a> | Français | <a href='http://he.html.net/tutorials/css/lesson3.php'>עברית</a> | <a href='http://it.html.net/tutorials/css/lesson3.php'>Italiano</a> | <a href='http://pl.html.net/tutorials/css/lesson3.php'>Polski</a> | <a href='http://pt-br.html.net/tutorials/css/lesson3.php'>Português (Brasil)</a> | <a href='http://ru.html.net/tutorials/css/lesson3.php'>Русский</a> | <a href='http://zh.html.net/tutorials/css/lesson3.php'>中文</a> | 		</span></p>

		
	</div>

	<!-- google_ad_section_end -->

<script type='text/javascript' language='Javascript' src='http://s1.lqcdn.com/m.min.js?dt=2.3.110104.1'></script>
	
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>
<script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
<script src="http://connect.facebook.net/en_US/all.js#xfbml=1" type="text/javascript"></script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
var fb = document.createElement('fb:like'); 
fb.setAttribute("href",""); 
fb.setAttribute("layout","button_count");
fb.setAttribute("show_faces","false");
fb.setAttribute("width","");
fb.setAttribute("style","position:relative; top:-3px;");
document.getElementById("FbCont").appendChild(fb);
//--><!]]>
</script>


</body>
</html>
