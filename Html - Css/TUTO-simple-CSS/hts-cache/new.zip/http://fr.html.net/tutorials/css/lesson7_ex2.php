<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<title>Exemple | Tutoriel CSS | HTML.net</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link rel="stylesheet" href="/tutorials/css/lesson7_ex2.css" type="text/css" media="all" />
</head>
<body>
	<h1>Deux groupes de liens</h1>

	<p><strong>Cépages de vins blancs :</strong></p>
	<ul>
	<li><a href="/tutorials/css/lesson7_ex2.php" class="whitewine">Riesling</a></li>
	<li><a href="/tutorials/css/lesson7_ex2.php" class="whitewine">Chardonnay</a></li>
	<li><a href="/tutorials/css/lesson7_ex2.php" class="whitewine">Pinot Blanc</a></li>
	</ul>

	<p><strong>Cépages de vins rouges :</strong></p>
	<ul>
	<li><a href="/tutorials/css/lesson7_ex2.php" class="redwine">Cabernet Sauvignon</a></li>
	<li><a href="/tutorials/css/lesson7_ex2.php" class="redwine">Merlot</a></li>
	<li><a href="/tutorials/css/lesson7_ex2.php" class="redwine">Pinot Noir</a></li>
	</ul>

	<p>Voici un exemple <a href="dok.htm">de lien sans classe</a> (il reste en bleu).</p>
	
	</body>
</html>